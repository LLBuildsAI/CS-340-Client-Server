package com.lawrencelangelier.modulethree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Displays the inventory management screen.
        setContentView(R.layout.activity_inventory);

        // References the SMS notification settings button.
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Opens the SMS notification settings screen.
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }
}