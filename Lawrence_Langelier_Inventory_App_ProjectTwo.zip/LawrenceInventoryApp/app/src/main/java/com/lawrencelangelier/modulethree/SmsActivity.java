package com.lawrencelangelier.modulethree;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    // Identifies the SMS permission request.
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    private TextView textViewSmsStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Displays the SMS notification settings screen.
        setContentView(R.layout.activity_sms);

        // References the SMS screen controls.
        Button buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonDeclineSms = findViewById(R.id.buttonDeclineSms);
        Button buttonReturnInventory = findViewById(R.id.buttonReturnInventory);
        textViewSmsStatus = findViewById(R.id.textViewSmsStatus);

        // Displays the current SMS permission status.
        updatePermissionStatus();

        // Checks and requests SMS permission when necessary.
        buttonAllowSms.setOnClickListener(v -> checkSmsPermission());

        // Keeps SMS notifications disabled when Not Now is selected.
        buttonDeclineSms.setOnClickListener(v ->
                textViewSmsStatus.setText(
                        "Status: SMS notifications are currently disabled."
                )
        );

        // Returns the user to the inventory screen.
        buttonReturnInventory.setOnClickListener(v -> {
            Intent intent = new Intent(SmsActivity.this, InventoryActivity.class);
            startActivity(intent);
        });
    }

    // Checks whether SMS permission has already been granted.
    private void checkSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            textViewSmsStatus.setText(
                    "Status: SMS notifications are enabled."
            );

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    // Updates the displayed SMS permission status.
    private void updatePermissionStatus() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            textViewSmsStatus.setText(
                    "Status: SMS notifications are enabled."
            );

        } else {

            textViewSmsStatus.setText(
                    "Status: SMS notifications are currently disabled."
            );
        }
    }

    // Handles the user's response to the SMS permission request.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {

            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                textViewSmsStatus.setText(
                        "Status: SMS notifications are enabled."
                );

            } else {

                textViewSmsStatus.setText(
                        "Status: SMS permission was denied. Inventory features remain available."
                );
            }
        }
    }
}